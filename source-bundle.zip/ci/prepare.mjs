import { createHash } from "node:crypto";
import { readFileSync, copyFileSync, writeFileSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { execFileSync } from "node:child_process";

const digest = (bytes) => createHash("sha256").update(bytes).digest("hex");
export function overlayEntries(text, firstPatch) {
  const entries = text.split(/\r?\n/).map(line => line.split("#")[0].trim()).filter(Boolean);
  if (!entries.length || entries[0] !== firstPatch || new Set(entries).size !== entries.length
    || entries.some(name => !/^[a-zA-Z0-9_.-]+\.patch$/.test(name)))
    throw new Error("Invalid ordered overlay series");
  return entries;
}
export function checkBaseline(engine, baseline) {
  const revision = execFileSync("git", ["-C", engine, "rev-parse", "HEAD"], { encoding: "utf8" }).trim();
  if (revision !== baseline.gitRevision) throw new Error("Upstream revision differs from the reviewed source");
  if (readFileSync(join(engine, "build", "CHROMIUM_VERSION"), "utf8").trim() !== baseline.chromiumVersion)
    throw new Error("Chromium version changed");
  const series = readFileSync(join(engine, "patches", "series"));
  if (digest(series) !== baseline.seriesSha256) throw new Error("Patch series bytes changed");
  const entries = series.toString("utf8").split(/\r?\n/).map((line) => line.split("#")[0].trim()).filter(Boolean);
  if (entries.length !== baseline.patchCount) throw new Error("Patch count changed");
  const hash = createHash("sha256");
  for (const name of entries) {
    if (!/^[a-zA-Z0-9_.-]+\.patch$/.test(name)) throw new Error("Unsafe patch name");
    hash.update(name).update("\0").update(readFileSync(join(engine, "patches", name))).update("\0");
  }
  if (hash.digest("hex") !== baseline.patchContentsSha256) throw new Error("Upstream patch contents changed");
  return { series, entries };
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const engine = resolve(process.argv[2] ?? "engine");
  const bundle = resolve(dirname(fileURLToPath(import.meta.url)), "..");
  const baseline = JSON.parse(readFileSync(join(bundle, "kernel", "baseline.json"), "utf8"));
  const { series } = checkBaseline(engine, baseline);
  const overlays = overlayEntries(readFileSync(join(bundle, "kernel", "series.overlay"), "utf8"), baseline.overlayPatch);
  const inputs = JSON.parse(readFileSync(join(bundle, "build-inputs.json"), "utf8"));
  for (const [name, expected] of Object.entries(inputs.files)) {
    if (!/^[a-zA-Z0-9_./-]+$/.test(name) || name.split("/").includes("..")) throw new Error("Unsafe bundle path");
    if (digest(readFileSync(join(bundle, name))) !== expected) throw new Error(`Bundle integrity failed: ${name}`);
  }
  for (const name of overlays) {
    const patch = join(bundle, "kernel", name);
    execFileSync("git", ["apply", "--numstat", patch], { cwd: engine, stdio: "inherit" });
    copyFileSync(patch, join(engine, "patches", name));
  }
  writeFileSync(join(engine, "patches", "series"), Buffer.concat([series, Buffer.from(`${series.at(-1) === 10 ? "" : "\n"}${overlays.join("\n")}\n`)]));
  // A new overlay must be reflected in the build manifest, never labelled as
  // the original upstream build. The actual build later replaces this record.
  execFileSync("python3", ["scripts/validate-release-baseline.py", "--refresh"], { cwd: engine, stdio: "inherit" });
  console.log("Pinned source verified; experimental overlay appended");
}
