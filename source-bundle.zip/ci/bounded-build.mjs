import { spawn } from "node:child_process";
import { appendFileSync, createWriteStream, writeFileSync } from "node:fs";
import { cpus, freemem, totalmem } from "node:os";
import { resolve } from "node:path";
import { fileURLToPath } from "node:url";

export function buildBudgetMs(startedAtMs, nowMs = Date.now()) {
  if (!Number.isSafeInteger(startedAtMs) || startedAtMs > nowMs || startedAtMs < nowMs - 350 * 60000)
    throw new Error("Invalid runner start time");
  const available = Math.min(270 * 60000, startedAtMs + 315 * 60000 - nowMs);
  if (available < 5 * 60000) throw new Error("Insufficient time to compile and checkpoint safely");
  return available;
}

export function buildState(exitCode, deadlineReached) {
  if (exitCode === 0) return "complete";
  return deadlineReached ? "checkpoint" : "failed";
}

/** @returns {Promise<{schemaVersion: number, validatedBrowser: boolean, state: string, exitCode: number | null, deadlineReached: boolean, elapsedSeconds: number, progress: {completed: number, total: number} | null, error: string | null}>} */
export async function runBoundedBuild({ command, args, cwd, budgetMs, output = "native-build.log" }) {
  if (!Number.isFinite(budgetMs) || budgetMs <= 0) throw new Error("Invalid build budget");
  const log = createWriteStream(output);
  /** @type {{completed: number, total: number} | null} */
  let progress = null;
  let carry = "", deadlineReached = false, childError;
  const started = Date.now();
  const child = spawn(command, args, { cwd, windowsHide: true, stdio: ["ignore", "pipe", "pipe"] });
  const consume = (chunk, stream) => {
    log.write(chunk); stream.write(chunk);
    carry += chunk.toString();
    const lines = carry.split(/[\r\n]/); carry = lines.pop()?.slice(-4096) ?? "";
    for (const line of lines) {
      const match = /^\[(\d+)\/(\d+)\]/.exec(line);
      if (match) progress = { completed: Number(match[1]), total: Number(match[2]) };
    }
  };
  child.stdout.on("data", data => consume(data, process.stdout));
  child.stderr.on("data", data => consume(data, process.stderr));
  child.on("error", error => { childError = error; });
  const timer = setTimeout(() => {
    if (child.exitCode !== null || !child.pid) return;
    deadlineReached = true;
    console.log("::notice::Compile budget reached; stopping this owned build tree before the runner timeout to save the compiler cache.");
    if (process.platform === "win32") {
      const killer = spawn("taskkill.exe", ["/PID", String(child.pid), "/T", "/F"], { windowsHide: true, stdio: "inherit" });
      killer.on("error", error => { childError = error; child.kill(); });
    } else child.kill("SIGTERM");
  }, budgetMs);
  const heartbeat = setInterval(() => {
    console.log(JSON.stringify({ elapsedMinutes: Math.round((Date.now() - started) / 60000), progress, logicalCpus: cpus().length,
      availableGiB: Math.round(freemem() / 1024 ** 3 * 10) / 10, totalGiB: Math.round(totalmem() / 1024 ** 3) }));
  }, 5 * 60000);
  const exitCode = await new Promise(resolveExit => child.once("close", resolveExit));
  clearTimeout(timer); clearInterval(heartbeat);
  await new Promise(resolveLog => log.end(resolveLog));
  return { schemaVersion: 1, validatedBrowser: false, state: childError ? "failed" : buildState(exitCode, deadlineReached),
    exitCode, deadlineReached, elapsedSeconds: Math.round((Date.now() - started) / 1000), progress, error: childError?.message ?? null };
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const engine = resolve(process.argv[2] ?? "engine");
  const budgetMs = buildBudgetMs(Number(process.env.CI_JOB_STARTED_MS));
  const command = process.platform === "win32" ? "C:/Program Files/Git/bin/bash.exe" : "bash";
  const report = await runBoundedBuild({ command, args: ["scripts/build.sh", "windows-x64"], cwd: engine, budgetMs });
  writeFileSync("build-state.json", JSON.stringify(report, null, 2) + "\n");
  if (process.env.GITHUB_OUTPUT) appendFileSync(process.env.GITHUB_OUTPUT, `state=${report.state}\n`);
  console.log(JSON.stringify(report));
  if (report.state === "failed") process.exitCode = 1;
}
