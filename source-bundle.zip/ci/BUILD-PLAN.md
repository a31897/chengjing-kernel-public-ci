# Bounded experimental Windows build

The previous 2-job cold build reached 27,735 of 58,405 Ninja tasks before its
350-minute job timeout. Its runner was destroyed without a compiler checkpoint.
That run cannot be resumed. Task counts are not a linear time estimate.

## Revised execution

- Use only the existing approved public repository and standard `windows-2022`
  runner. Do not change billing, repository visibility, or runner size.
- Compile with at most four jobs, bounded by the runner's logical CPU count.
- Retain the full browser, official release optimization, PGO and ThinLTO.
  Overlay 0178 changes only Windows ThinLTO backend concurrency from all threads
  to two. This is a memory-pressure mitigation, not a guarantee a 16 GiB runner
  can finish the final link. It can make linking slower.
- Hash-pin sccache 0.19.0. Before the full build, compile an actual object twice,
  require a real cache hit, and compare both with a direct compiler control.
- Keep a local compiler cache bounded to 8 GB and save it through Actions cache.
  Do not increase the repository's cache quota or enable paid cache storage.
  The default cache quota can evict older entries. No full Chromium source tree,
  profiles, SDK, installed browser, or private configuration enters the cache.
- Key the cache by the source-bundle hash (including ordered native patches and
  build scripts), runner image version, sccache version and actual clang hash.
  Keep the ephemeral source path stable. Cache hits still depend on compiler
  inputs; this is not blind reuse of a previous `out/` directory or DLL.
- Stop each compile after at most 270 minutes, or 315 minutes after the initial
  preflight, whichever is earlier. Reserve the rest of the 350-minute job for
  flushing, uploading and checking the cache, plus packaging/measurement.
- A later slice starts only after a deliberate compile-budget checkpoint and a
  lookup confirms that exact saved cache exists. Compilation errors do not
  trigger a retry. Require at least 100 measured cache writes/hits and at least
  50% reusable compiler requests before handing off. Stop after three slices;
  no scheduled or unbounded reruns.
- The cache is finite: eviction, uncacheable compilation, runner-image changes,
  restore failures and final linking can prevent completion. Inspect measured
  hit statistics and actual Ninja progress rather than claiming a resume
  percentage. Generated actions and uncached outputs run again in each slice.

## Acceptance boundary

An optional local MSVC cache integration test needs an explicitly supplied
ASCII writable test directory (`CHENGJING_CACHE_TEST_ROOT`). Local attempts
encountered ANSI path decoding and denied temporary-directory writes. Do not
count this as a passing cache control. The runner-side check is mandatory and
uses its actual pinned Chromium clang-cl, not the optional MSVC test.

Only Ninja exit code zero permits binary packaging and browser measurement.
An incomplete final slice fails the workflow. A tiny evidence artifact is not a
browser. All candidates remain `validated: false`; cached compilation is not an
independent reproducible-build proof. Real headed GPU measurements, full payload
hash review, strict known-pixel/PBO tests and explicit restriction tests remain
required before runtime adoption. Known pixel provenance and independent WebGPU
rendering are not implemented by this build change.
