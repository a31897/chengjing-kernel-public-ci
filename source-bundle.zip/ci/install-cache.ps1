param([Parameter(Mandatory=$true)][string]$ToolsRoot)
$ErrorActionPreference = 'Stop'
$root = [IO.Path]::GetFullPath($ToolsRoot)
$destination = [IO.Path]::GetFullPath((Join-Path $root 'chengjing-sccache-0.19.0'))
if (-not $destination.StartsWith($root.TrimEnd('\')+'\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Unsafe tools path' }
New-Item -ItemType Directory -Path $destination -Force | Out-Null
$archive = Join-Path $destination 'sccache.zip'
Invoke-WebRequest -Uri 'https://github.com/mozilla/sccache/releases/download/v0.19.0/sccache-v0.19.0-x86_64-pc-windows-msvc.zip' -OutFile $archive
if ((Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant() -ne '28be8c61f6b2c89b9eb2869f6af7f78e6f992e78a8abae0ce855fcc129cbeac1') { throw 'sccache archive digest mismatch' }
Expand-Archive -LiteralPath $archive -DestinationPath (Join-Path $destination 'bin') -Force
$executables = @(Get-ChildItem -LiteralPath (Join-Path $destination 'bin') -Recurse -File -Filter sccache.exe)
if ($executables.Count -ne 1) { throw 'Expected one pinned sccache executable' }
$exe = $executables[0]
& $exe.FullName --version
if ($LASTEXITCODE -ne 0) { throw 'sccache version check failed' }
if ($env:GITHUB_PATH) { $exe.DirectoryName | Add-Content -LiteralPath $env:GITHUB_PATH }
Write-Output $exe.FullName
