import { createServer } from "node:http";
import { spawn } from "node:child_process";
import { randomUUID } from "node:crypto";
import { mkdtempSync, writeFileSync, readFileSync, existsSync, statSync } from "node:fs";
import { tmpdir } from "node:os";
import { resolve, join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { renderWorkerSource, collectRenderSnapshot, evaluateRenderContexts, compareRenderSessions, evaluateHardwareRestriction, knownPixelContractPassed } from "../render-probe.mjs";

const binary = resolve(process.argv[2] ?? "missing-binary");
const output = resolve(process.argv[3] ?? "rendering-results.json");
const managerIndex = process.argv.indexOf("--manager-instance");
const managerFile = managerIndex >= 0 ? process.argv[managerIndex + 1] : null;
const allowTestProfiles = process.argv.includes("--allow-test-profiles");
const holdIndex = process.argv.indexOf("--hold-ms");
const holdMs = holdIndex >= 0 ? Number(process.argv[holdIndex + 1]) : 0;
if (!Number.isInteger(holdMs) || holdMs < 0 || holdMs > 30000) throw new Error("Invalid inspection hold duration");
const headed = !!managerFile || process.argv.includes("--headed");
const readbackNoise = process.argv.includes("--readback-noise");
const imageOnlyNoise = process.argv.includes("--image-only-noise");
if (imageOnlyNoise && readbackNoise) throw new Error("Choose image-only or legacy umbrella noise, not both");
const blockHardware = process.argv.includes("--block-hardware");
const restrictWebGpu = process.argv.includes("--restrict-webgpu");
if (!existsSync(binary)) throw new Error("Built browser is missing");
const bundle = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const root = mkdtempSync(join(tmpdir(), "chengjing-ci-render-"));
const managerProfiles = new Map();
const sameDirectory = (a, b) => {
  const first = statSync(a, { bigint: true }), second = statSync(b, { bigint: true });
  return first.isDirectory() && second.isDirectory() && first.ino !== 0n && first.dev === second.dev && first.ino === second.ino;
};
let manager;
if (managerFile) {
  if (imageOnlyNoise) throw new Error("Image-only candidate must use its explicitly supplied rebuilt native kernel, not an old pinned manager runtime");
  if (readbackNoise && blockHardware) throw new Error("Choose one native acceptance policy");
  manager = JSON.parse(readFileSync(resolve(managerFile), "utf8"));
  const markerPath = join(dirname(dirname(resolve(managerFile))), "render-lab.json");
  const marker = existsSync(markerPath) ? JSON.parse(readFileSync(markerPath, "utf8")) : null;
  const owned = marker?.purpose === "render-acceptance-lab";
  if ((!owned && !allowTestProfiles) || !sameDirectory(dirname(resolve(managerFile)), manager.dataRoot)
    || !Number.isInteger(manager.port) || manager.port < 1 || manager.port > 65535 || !/^[a-f0-9]{64}$/.test(manager.token))
    throw new Error("Refusing an unowned manager workspace");
  const expectedPolicy = readbackNoise ? "readback-noise" : blockHardware ? "block-hardware" : "current";
  if ((marker?.policy ?? "current") !== expectedPolicy || (!owned && expectedPolicy !== "current"))
    throw new Error("The requested policy does not match the owned test workspace");
}
const managerRequest = async (path, value) => {
  const response = await fetch(`http://127.0.0.1:${manager.port}${path}`, {
    method: value === undefined ? "GET" : "POST", headers: { "x-local-token": manager.token, "content-type": "application/json" },
    body: value === undefined ? undefined : JSON.stringify(value), signal: AbortSignal.timeout(30000),
  });
  const result = await response.json();
  if (!response.ok) throw new Error(`Owned manager request failed: ${result.error}`);
  return result;
};
const key = randomUUID();
let pending;
const observations = [];
const comparisons = [];
const server = createServer(async (req, res) => {
  const url = new URL(req.url, "http://127.0.0.1");
  const send = (status, type, body) => { res.writeHead(status, { "content-type": type, "cache-control": "no-store" }); res.end(body); };
  if (url.pathname === "/") {
    return send(200, "text/html", `<!doctype html><meta charset="utf-8"><title>Native rendering acceptance</title><style>body{font:14px Consolas,monospace;padding:28px;background:#f3f5f8;color:#202839}main{white-space:pre-wrap;overflow-wrap:anywhere}</style><main>Collecting native APIs. No third-party requests.</main><script type="module">import{collectRenderContexts,evaluateRenderContexts,runKnownPixelRegression}from'/render-probe.mjs';const report=await collectRenderContexts(${JSON.stringify(key)});report.knownPixels=runKnownPixelRegression();document.querySelector('main').textContent=JSON.stringify({identity:report.window?.identity,canvas:report.window?.canvas,webgl:report.window?.webgl,webgpu:report.window?.webgpu,exposure:report.window?.exposure,knownPixels:report.knownPixels,checks:evaluateRenderContexts(report)},null,2);const result=await(await fetch('/result?key=${key}',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(report)})).json();if(result.reload)location.reload();</script>`);
  }
  if (url.pathname === "/render-probe.mjs") return send(200, "text/javascript", readFileSync(join(bundle, "render-probe.mjs")));
  if (url.searchParams.get("key") !== key) return send(403, "text/plain", "Forbidden");
  if (url.pathname === "/probe/render-worker.js") {
    res.setHeader("service-worker-allowed", "/probe/render-scope/");
    return send(200, "text/javascript", renderWorkerSource());
  }
  if (url.pathname === "/probe/render-frame") {
    const nonce = url.searchParams.get("nonce");
    if (!/^[a-f0-9-]{36}$/.test(nonce)) return send(400, "text/plain", "Invalid nonce");
    return send(200, "text/html", `<!doctype html><script>const collect=${collectRenderSnapshot.toString()};collect().then(snapshot=>parent.postMessage({renderNonce:${JSON.stringify(nonce)},snapshot},location.origin)).catch(error=>parent.postMessage({renderNonce:${JSON.stringify(nonce)},snapshot:{error:String(error)}},location.origin));</script>`);
  }
  if (url.pathname === "/result" && req.method === "POST") {
    try {
      const chunks = []; let size = 0;
      for await (const chunk of req) { size += chunk.length; if (size > 2 * 1024 * 1024) throw new Error("Report too large"); chunks.push(chunk); }
      if (!pending) return send(409, "text/plain", "No pending case");
      const report = JSON.parse(Buffer.concat(chunks));
      observations.push({ label: pending.labels.shift(), report, checks: evaluateRenderContexts(report) });
      const reload = pending.labels.length > 0;
      send(200, "application/json", JSON.stringify({ reload }));
      if (!reload) pending.resolve();
    } catch (error) { pending?.reject(error); send(400, "text/plain", String(error)); }
    return;
  }
  send(404, "text/plain", "Not found");
});
await new Promise((done) => server.listen(0, "127.0.0.1", done));
const origin = `http://127.0.0.1:${server.address().port}`;
async function run(labels, profile, seed) {
  let child;
  let stderr = "";
  let profileId;
  try {
    if (manager) {
      profileId = managerProfiles.get(profile);
      if (!profileId) {
        const created = await managerRequest("/api/profiles", {
          name: `Rendering acceptance ${profile}`, note: "Disposable isolation acceptance profile. No account data copied.", group: "Isolation acceptance",
          identityMode: seed === "host" ? "native" : "isolated",
          restrictWebGpu: seed !== "host" && restrictWebGpu,
          proxyMode: "direct", storageMode: "persistent", restrictWebRtc: true, followProxyRegion: false,
        });
        profileId = created.id;
        managerProfiles.set(profile, profileId);
        if (seed !== "host" && restrictWebGpu) {
          const current = await managerRequest("/api/state");
          if (current.profiles.find(row => row.id === profileId)?.restrictWebGpu !== true)
            throw new Error("The manager did not persist the requested per-profile WebGPU policy");
        }
      }
    }
    await new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error(`Rendering timeout: ${labels.join(", ")}`)), 210000);
      pending = { labels: [...labels], resolve: () => { clearTimeout(timer); resolve(); }, reject: (error) => { clearTimeout(timer); reject(error); } };
      if (manager) {
        managerRequest(`/api/profiles/${profileId}/open`, { url: origin }).catch(pending.reject);
        return;
      }
      const args = [...(headed ? [] : ["--headless=new"]), "--no-first-run", "--no-default-browser-check", "--disable-background-networking", `--user-data-dir=${join(root, profile)}`, `--fingerprint=${seed}`,
        ...(seed === "host" ? [] : ["--fingerprint-platform=windows", ...(readbackNoise ? ["--fingerprint-noise"] : []), ...(imageOnlyNoise ? ["--fingerprint-image-noise"] : []), ...(blockHardware ? ["--disable-reading-from-canvas", "--disable-webgl"] : []), ...(blockHardware || restrictWebGpu ? ["--disable-features=WebGPUService"] : [])]), origin];
      child = spawn(binary, args, { cwd: dirname(binary), stdio: ["ignore", "ignore", "pipe"], windowsHide: !headed });
      child.stderr.on("data", (chunk) => { stderr = (stderr + chunk.toString()).slice(-12000); });
      child.on("error", pending.reject);
      child.on("exit", (code) => { if (pending?.labels.length) pending.reject(new Error(`Browser exited before report (${code}): ${stderr}`)); });
    });
    if (holdMs) await new Promise((resolve) => setTimeout(resolve, holdMs));
  } finally {
    pending = undefined;
    if (manager && profileId) await managerRequest(`/api/profiles/${profileId}/stop`, {});
    if (child && child.exitCode === null) {
      child.kill();
      await new Promise((resolve) => {
        const timer = setTimeout(resolve, 10000);
        child.once("exit", () => { clearTimeout(timer); resolve(); });
      });
    }
  }
}
let failure;
try {
  if (manager) {
    const state = await managerRequest("/api/state");
    const expected = readbackNoise ? "readback-noise" : blockHardware ? "block-hardware" : "current";
    if ((state.acceptancePolicy ?? "current") !== expected) throw new Error("The running manager did not apply the requested test policy");
  }
  await run(["native-control"], "control", "host");
  await run(["A-initial", "A-real-reload"], "A", "73512901");
  await run(["A-process-restart"], "A", "73512901");
  await run(["B-initial"], "B", "89123451");
  const [control, first, refresh, restart, second] = observations;
  for (const [label, a, b, relation] of [
    ["A reload", first, refresh, "same-profile"], ["A process restart", first, restart, "same-profile"],
    ["A versus B", first, second, "different-profile"], ["A versus native", first, control, "different-profile"], ["B versus native", second, control, "different-profile"],
  ]) comparisons.push({ label, checks: compareRenderSessions(a.report, b.report, relation) });
} catch (error) { failure = String(error); }
finally {
  server.closeAllConnections(); await new Promise((done) => server.close(done));
  const required = observations.flatMap((row) => row.checks.filter((check) => !check.id.startsWith("coverage.")));
  const measuredPass = !failure && observations.length === 5 && comparisons.length === 5 && observations.every(row => knownPixelContractPassed(row.report.knownPixels)) && required.every((check) => check.pass) && comparisons.every((row) => row.checks.every((check) => check.pass));
  const restrictionChecks = blockHardware && observations[0]
    ? observations.slice(1).map(row => ({ label: row.label, checks: evaluateHardwareRestriction(observations[0].report, row.report) })) : [];
  const privacyRestrictionPassed = blockHardware && !failure && restrictionChecks.length === 4
    && restrictionChecks.every(row => row.checks.length === 40 && row.checks.every(check => check.pass));
  const webgpuRestrictionChecks = restrictWebGpu && observations[0]
    ? observations.slice(1).map(row => ({ label: row.label, checks: evaluateHardwareRestriction(observations[0].report, row.report).filter(check => check.id.endsWith(".webgpu")) })) : [];
  const webgpuRestrictionPassed = restrictWebGpu && !failure && webgpuRestrictionChecks.length === 4
    && webgpuRestrictionChecks.every(row => row.checks.length === 5 && row.checks.every(check => check.pass));
  const requestedPolicyPassed = blockHardware ? privacyRestrictionPassed : restrictWebGpu ? webgpuRestrictionPassed : measuredPass;
  writeFileSync(output, JSON.stringify({
    schemaVersion: 1, measuredAt: new Date().toISOString(), measuredPass, privacyRestrictionPassed, restrictionChecks, webgpuRestrictionPassed, webgpuRestrictionChecks, requestedPolicyPassed, productionValidated: false, failure,
    policy: { readbackNoise, imageOnlyNoise, blockHardware, restrictWebGpu, launcher: manager ? "manager-test-profiles" : "native-process" },
    method: `Actual Chromium; ${headed ? "headed desktop" : "headless CI"}; ordinary local page APIs and real reload/process restart; no CDP and no getter overrides.`,
    limitations: "This is not a headed real-GPU desktop baseline. Unsupported APIs remain unverified. 0174 does not implement WebGPU independence.",
    observations, comparisons,
  }, null, 2));
  console.log(JSON.stringify({ measuredPass, privacyRestrictionPassed, webgpuRestrictionPassed, requestedPolicyPassed, productionValidated: false, output, failure }));
  if (!requestedPolicyPassed) process.exitCode = 1;
}
