import { createHash } from "node:crypto";
import { execFileSync, spawnSync } from "node:child_process";
import { appendFileSync, existsSync, mkdirSync, readFileSync, unlinkSync, writeFileSync } from "node:fs";
import { join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

export const SCCACHE_VERSION = "0.19.0";
export const SCCACHE_ARCHIVE_SHA256 = "28be8c61f6b2c89b9eb2869f6af7f78e6f992e78a8abae0ce855fcc129cbeac1";
const hash = bytes => createHash("sha256").update(bytes).digest("hex");

export function cachedWindowsArgs(text) {
  if (/^\s*(cc_wrapper|concurrent_links|chrome_pgo_phase|use_thin_lto)\s*=/m.test(text))
    throw new Error("Unexpected existing compiler-cache or optimization override");
  return `${text.trimEnd()}\n\n# Experimental CI transport only; retain official optimization and features.\ncc_wrapper = "sccache"\n`;
}

export function cacheNamespace(bundleDigest, imageVersion, compilerDigest) {
  if (!/^[a-f0-9]{64}$/.test(bundleDigest) || !/^[a-f0-9]{64}$/.test(compilerDigest)
    || !/^[a-zA-Z0-9._-]{1,100}$/.test(imageVersion ?? ""))
    throw new Error("Incomplete cache input identity");
  return "chengjing-cc-v1-" + hash(JSON.stringify({ bundleDigest, imageVersion, compilerDigest, sccache: SCCACHE_VERSION }));
}

export function cacheHits(stats) {
  const counts = stats?.stats?.cache_hits?.counts;
  if (!counts || typeof counts !== "object" || Array.isArray(counts))
    throw new Error("Unrecognized sccache statistics");
  return Object.values(counts).reduce((sum, n) => {
    if (!Number.isSafeInteger(n) || n < 0) throw new Error("Invalid cache hit count");
    return sum + n;
  }, 0);
}

export function checkHandoffStats(stats) {
  const hits = cacheHits(stats), writes = stats?.stats?.cache_writes;
  const requests = stats?.stats?.compile_requests;
  if (!Number.isSafeInteger(writes) || writes < 0 || !Number.isSafeInteger(requests) || requests < 1)
    throw new Error("Invalid compiler-cache write statistics");
  if (hits + writes < 100 || (hits + writes) / requests < 0.5)
    throw new Error("Too little real compiler work was cached; refusing a blind continuation");
  return { hits, writes, requests, reusableFraction: (hits + writes) / requests };
}

function run(exe, args, cwd) {
  const result = spawnSync(exe, args, { cwd, encoding: "utf8", windowsHide: true });
  if (result.error || result.status !== 0)
    throw new Error(`${exe} failed: ${result.error ?? result.stderr ?? result.status}`);
  return result.stdout;
}

export function verifyObjectCache(compiler, dir, engine, extraFlags = []) {
  if (!existsSync(compiler)) throw new Error("Native compiler is missing");
  mkdirSync(dir, { recursive: true });
  const source = join(dir, "cache-control.cc"), object = join(dir, "cache-control.obj");
  writeFileSync(source, "extern \"C\" int cache_control(int n) { return n * 17 + 3; }\n");
  const flags = ["/c", source, "/nologo", "/O2", "/GS-", "/showIncludes", ...extraFlags, `/Fo${object}`];
  run("sccache", ["--zero-stats"], engine);
  run("sccache", [compiler, ...flags], engine);
  const first = hash(readFileSync(object));
  unlinkSync(object);
  run("sccache", [compiler, ...flags], engine);
  const second = hash(readFileSync(object));
  const stats = JSON.parse(run("sccache", ["--show-stats", "--stats-format=json"], engine));
  if (first !== second || cacheHits(stats) < 1) throw new Error("Compiler cache did not reproduce a real object cache hit");
  unlinkSync(object);
  run(compiler, flags, engine);
  if (first !== hash(readFileSync(object))) throw new Error("Cached object differs from direct compiler control");
  const report = { validatedBrowser: false, status: "compiler-cache-control-only", objectSha256: first, hits: cacheHits(stats) };
  return report;
}

export function verifyCompilerCache(engine, workspace, env = process.env) {
  const compiler = join(workspace, "src/third_party/llvm-build/Release+Asserts/bin/clang-cl.exe");
  const report = verifyObjectCache(compiler, join(workspace, "cache-preflight"), engine);
  writeFileSync("cache-preflight.json", JSON.stringify(report, null, 2) + "\n");
  run("sccache", ["--zero-stats"], engine);
  const bundleDigest = readFileSync("source-bundle.sha256", "utf8").trim();
  const prefix = cacheNamespace(bundleDigest, env.ImageVersion, hash(readFileSync(compiler)));
  if (env.GITHUB_OUTPUT) appendFileSync(env.GITHUB_OUTPUT, `prefix=${prefix}\n`);
  return { ...report, prefix };
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const [command, engineArg, workspaceArg] = process.argv.slice(2);
  const engine = resolve(engineArg ?? "engine");
  if (command === "configure") {
    const file = join(engine, "build/args/windows-x64.gn");
    writeFileSync(file, cachedWindowsArgs(readFileSync(file, "utf8")));
    execFileSync("python3", ["scripts/validate-release-baseline.py", "--refresh"], { cwd: engine, stdio: "inherit", windowsHide: true });
  } else if (command === "preflight") {
    console.log(JSON.stringify(verifyCompilerCache(engine, resolve(workspaceArg ?? "missing-workspace"))));
  } else if (command === "key") {
    const compiler = join(resolve(workspaceArg ?? "missing-workspace"), "src/third_party/llvm-build/Release+Asserts/bin/clang-cl.exe");
    const prefix = cacheNamespace(readFileSync("source-bundle.sha256", "utf8").trim(), process.env.ImageVersion, hash(readFileSync(compiler)));
    appendFileSync(process.env.GITHUB_OUTPUT, `prefix=${prefix}\n`);
    console.log(`Cache namespace: ${prefix}`);
  } else if (command === "check-stats") {
    const state = JSON.parse(readFileSync("build-state.json", "utf8"));
    if (state.state === "checkpoint")
      console.log(JSON.stringify(checkHandoffStats(JSON.parse(readFileSync("compiler-cache-stats.json", "utf8")))));
  } else throw new Error("Expected configure, key, preflight, or check-stats");
}
