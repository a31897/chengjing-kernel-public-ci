# Known-Pixel Provenance: Repair Not Yet Implemented

This is a source-verified repair design and a regression probe, **not** a native
0175 fix or a replacement runtime. No patch is submitted merely to make the
current disjoint-draw assertion pass.

## Verified Source Facts

`0175-source-check.ts` fetches only three source files, 202,117 bytes in total,
from the fixed Chromium tag `155.0.8059.85`. Each file has an independent pinned
SHA-256. It checks the existing manager kernel baseline, replays every matching
patch in the actual upstream series with real `git apply --check` and applies
them to those complete files. The source evidence is written to
`0175-source-evidence.json`; it is static source verification, not a browser test.

The resulting source establishes two distinct losses of provenance:

1. `Canvas2DRecorderContext::Draw` sets `apostate_drawn_ = true` and clears all
   of `apostate_kept_` before the actual draw. It does so even when later bounds,
   clipping, alpha or blending leave the previously written pixels unchanged.
2. Whole-canvas `putImageData` records only `apostate_drawn_ = false` and clears
   the kept region. A later draw flips the flag and loses the provenance of
   every earlier script-written pixel, not just the affected area.

`DrawInternal` already distinguishes composited draws, `copy`/`kSrc` clearing,
and ordinary draws using `ComputeDirtyRect`. Its dirty rectangle includes CTM,
shadow extent and clip bounds. It is a conservative invalidation bound, not a
map of which individual pixels changed.

## Rejected Incomplete Fixes

- Never clearing `apostate_kept_` would preserve exact readback but create a
  fingerprint bypass: write pixels over the whole canvas, then draw anywhere.
- Replacing the global clear with a dirty-bounds difference would handle a
  fully disjoint drawing, but invalidate untouched pixels inside a hollow
  stroke's bounds, a zero-alpha draw, or a destination-over draw over an opaque
  patch. It is not an exact provenance repair.
- A threshold, a special-case test pattern, skipping FBOs, or deleting the
  failing assertions would hide a failure rather than repair API semantics.

## Required Native Repair

The source of truth must follow the actual clean backing-store pixels, not a
global flag or JavaScript getters. The readback layer must preserve pixels a
page supplied and which subsequent operations have not actually changed.

A precise implementation can use one of these explicitly scoped architectures:

1. Propagate per-pixel known/raster provenance through native raster coverage,
   CPU/GPU backing stores and image copies. Apply CTM, clip, stroke coverage,
   shadows, filters, destination-dependent composites and layers to that
   provenance with the same effective operation as the color surface. Whole
   `putImageData` marks the full written surface known instead of dropping it.
2. Maintain immutable native snapshots/tiles for script writes, keyed by their
   actual storage format and color space. At readback, preserve only known
   pixels whose current **clean** backing-store value still matches the stored
   written value. Do not replace an older write's reference with a later
   arbitrary canvas snapshot: that would accidentally bless intervening host
   raster output as script-supplied data. Overlapping writes replace references
   only for their real destinations.

The second design needs byte/format-exact comparisons before perturbation and
before readback color conversion. Comparing raw input `ImageData` against an
unpremultiplied read is insufficient: alpha quantization, float/HDR formats,
color-space conversion and GPU storage must match stock Chromium's pipeline.
Resource copies, resize/reset, OffscreenCanvas transfer, ImageBitmap, encoder
snapshots, layers and context loss must carry or invalidate provenance correctly.
Memory limits must not silently fall back to host readback or corrupt pixels.

These are changes to raster/resource provenance, not a safe one-line flag fix.
The currently available source-only checkout cannot demonstrate either design
without the full native build and regression measurements. No approximation is
being marked release-ready in its place.

## Regression Probe

`0175-known-pixels.ts` exports `runKnownPixelRegression()`. Serve it as part of a
local test page or a Worker module; it is not an injected browser override. It
creates fresh local canvases and uses only public drawing/readback APIs. It
tests both default and `willReadFrequently` contexts with opaque, precisely
known writes so alpha quantization does not create false failures.

The probe retains 24 required assertions: partial and whole-canvas writes,
unrelated anti-aliased draws, hollow-stroke bounds, alpha-zero no-ops,
destination-over over opaque pixels, transformed and clipped draws, disjoint
filter and shadow effects, and controls where `copy` or `clearRect` genuinely
must clear the known pixels. Errors and missing contexts are failures, not passes.

Run against stock host control first, then the old noise runtime and a freshly
built candidate in Window and supported Worker contexts. Save the byte counts
per case. A successful source replay, a TypeScript build, or a unit test of a
rectangle model is **not** a result for these browser assertions. Retain the
Canvas/WebGL/WebGPU cross-profile and restart checks separately; this probe
does not establish rendering isolation or detector acceptance.

```powershell
& '.\.tools\bun-windows-x64\bun.exe' local/kernel/0175-source-check.ts
```

The command above verifies source context only. It does not start a browser,
compile Chromium, alter the current kernel baseline, or edit existing profiles.
