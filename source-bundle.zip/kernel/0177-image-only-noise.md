# Image-Only Noise: Native Overlay, Not a Validated Runtime

`0177-image-only-profile-noise.patch` introduces the native opt-in switch
`--fingerprint-image-noise`. It enables only the existing Canvas/WebGL image
readback variation. It does not enable the umbrella switch's font-size or audio
variation. The legacy `--fingerprint-noise` switch retains its previous meaning.

No production profile, runtime, upstream patch, CI configuration or acceptance
gate is modified by this directory's checker. No commercial program is patched
or inspected. There are no JavaScript getter overrides, injected fingerprint
scripts or CDP changes.

## Native Policy

| Explicit Flags | Canvas/WebGL Image Policy | Font/Audio Umbrella Policy |
| --- | --- | --- |
| Neither switch | Off | Off |
| `--fingerprint-image-noise` | On, if a profile identity exists | Off |
| `--fingerprint-noise` | On, if a profile identity exists | On, if a profile identity exists |
| Both switches | Same image policy and seed as either alone | Legacy umbrella behavior |
| Any flags with host/no profile or empty identity | Off | Off |

The renderer launch switch list propagates the new flag to every renderer.
`ProfileImageNoiseEnabled()` and `ProfileImageNoiseBits()` are separate from the
legacy `ProfileNoiseEnabled()`/`ProfileNoiseBits(domain)` APIs. Font and audio
call sites are unchanged and continue to use only the umbrella APIs.

The legacy Canvas code did **not** use `ProfileNoiseBits(domain)`: the generic
API hashes `aliasmode/`, the requested domain, NUL and the identity, whereas the
legacy image policy hashes the exact 25-byte `apostate/canvas-noise/v1` plus NUL
domain and the identity. Changing Canvas to the generic domain API would have
silently changed old profiles' image seeds. The new no-argument image-bits API
preserves those exact old image-domain bytes and both `PersistentHash` calls.
Only the identity gate and hash-material construction are shared internally.

The complete Canvas pixel-algorithm body is byte-identical before/after this
overlay, following the already applied 0174 size-cutoff fix. The pixel mixer is
also unchanged. Canvas/WebGL encoding, readback and copy paths keep consuming
the same native `Enabled()`/`Seed()` policy. This avoids a new mode-dependent
seed split but does not prove those paths are otherwise correct.

## Reproduce the Verified Subset

```powershell
& '.\.tools\bun-windows-x64\bun.exe' local/kernel/0177-check.ts
& '.\.tools\bun-windows-x64\bun.exe' test ./local/kernel/0177-check.test.ts
```

The checker requires Windows x64, the existing Bun runtime, a Visual Studio C++
toolchain and Windows SDK libraries. It fetches or reuses nine fixed Chromium
155.0.8059.85 inputs, independently pinned by SHA-256. It also reconstructs the
four complete noise files created by the upstream patch series. It verifies
the upstream commit and the full ordered patch-content digest before replay.

Every matching upstream patch is checked/applied to the complete selected
sources. The entire existing 0174 and 0176 overlays are checked/applied first;
then all six files of 0177 pass real `git apply --check` and application. A
context-only mock file is not used as proof of patch applicability.

The checker additionally verifies that:

- The new switch is in the actual renderer propagation array that is copied to
  renderer command lines. This is a source assertion, not renderer execution.
- The complete Windows-font, periodic-wave and compressor source files remain
  byte-identical, use the old umbrella APIs and have no image-only API references.
- Every existing noise reference added by the full upstream patch series is
  recorded for review, including non-image call sites.
- The Canvas pixel-algorithm suffix and `MixProfileNoise` body remain identical.

## Native Compatibility Units

The checker compiles the actual before/after `profile_noise.cc` policy bodies
and the actual old/new Canvas `ResolvePolicy` bodies with MSVC. It uses real
C++ strings and the original, separately hash-pinned Chromium SuperFastHash C
implementation. Small adapters stand in for Chromium `CommandLine`, `Profile`,
`NoDestructor` and `StrCat` plumbing. These are explicitly policy-fragment units,
not full translation-unit, renderer-integration or browser tests.

Forty native combinations cover both initialized/uninitialized command lines,
two different identities, an empty identity, no profile, no switch, each switch,
both switches and an unrelated switch. They check unchanged old umbrella seeds
in all three real font/audio domains; zero generic domain bits in image-only
mode; unchanged Canvas seeds under the old flag; and identical image seeds
under old, image-only and combined flags. Repeated reads and a second native
test-process invocation must agree, while two identities must have different
image seeds. This is native policy determinism, not browser refresh/restart
acceptance.

`0177-verification.json` records source URLs/hashes, exact replay/compile/link
commands, every native result, reference audits and explicit limits. Generated
sources, objects, executable and cached inputs remain in ignored `.work/0177-*`.

## Gates Remain Closed

No complete affected translation unit or full Chromium candidate has been built
or measured by this checker. `fullTranslationUnitsCompiled`, `fullKernelBuilt`,
`browserMeasured` and `productionGateReleased` remain `false` in its result.

Image-only mode intentionally does **not** repair the unresolved known-pixel,
crop, encode/copy, WebGL FBO or WebGPU gaps. The existing failing assertions must
remain in the browser suite. A stable different seed is not proof of a correct
pixel pipeline, normal-looking fingerprint, or unlinkability.

Before adoption, build a new separately versioned, hash-pinned candidate and
run the unchanged headed host/control and multi-seed matrix across Window,
iframe, DedicatedWorker, SharedWorker and ServiceWorker. Compare image-only and
legacy umbrella modes separately; the image-only run must match the control's
font metrics and rendered audio for the same native profile, while all existing
pixel-semantics assertions still pass. Retain per-context repeated read,
refresh, process restart and seed-independence measurements. Unsupported or
failed routes remain unverified, never silently passed.

Keeping font/audio perturbation off also leaves their native host signals
observable; this option does not promise to hide all real device configuration.
No existing login environment should be changed solely because these source and
native policy-fragment checks pass.
