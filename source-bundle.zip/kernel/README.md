# Native Rendering Overlays: Not a Validated Browser Build

This directory carries an overlay for the exact upstream source revision in
`baseline.json`. It does not replace the running browser, change existing
profiles, enable `--fingerprint-noise`, or modify `.tools/kernel-source`.

## Scope

The upstream policy exempts every canvas with either side below 16 pixels.
That makes the same unclipped drawing on an 8x8 canvas differ from its copy on
a larger canvas when profile readback noise is enabled. Patch 0174 removes
that positive-size cutoff while retaining the guards for zero and negative
dimensions. It also removes the corresponding tiny-canvas explanations from
the source comments. The perturbation algorithm and WebGPU behavior are not
changed by 0174.

0176 additionally propagates existing explicit Canvas/WebGL restrictions to
all renderers and enforces them at native OffscreenCanvas and WebGL provider
boundaries. It does not disable APIs on an ordinary launch and does not
implement virtual GPU rendering. See `0176-explicit-restrictions.md`.

0177 separates image-only opt-in from the umbrella font/audio policy while
preserving the exact previous image domain and seed. It does not repair the
readback algorithm. See `0177-image-only-noise.md`; source checks and native
policy snippet tests do not establish browser correctness.

0178 bounds Windows ThinLTO backend workers to two for the experimental
checkpointed CI build. Official optimization, PGO, ThinLTO and browser features
remain enabled. It is not an isolation fix or proof that the hosted runner has
enough link memory. See `ci/BUILD-PLAN.md` for the three-slice, finite-cache plan.

`series.overlay` lists the additional patch to place after the complete pinned
upstream series. The checked-in baseline records the upstream commit, Chromium
version, raw series hash, all 151 patch contents in order, and the hash format.
The checker refuses to run against a changed baseline.

## Reproduce the Verified Subset

Run from the manager repository root with its existing Bun runtime:

```powershell
& '.\.tools\bun-windows-x64\bun.exe' test ./local/kernel/check.test.ts
& '.\.tools\bun-windows-x64\bun.exe' local/kernel/check.ts
```

The CLI accepts an alternative local upstream source directory as its sole
argument. It does not download Chromium or install build tools. A Windows x64
Visual Studio C++ toolchain with `cl.exe` and `link.exe` is required. No Windows
SDK or CRT library is needed for the small native predicate regression.

The checker performs these distinct operations:

1. It verifies the exact upstream revision, Chromium version and complete
   ordered patch-series bytes against `baseline.json`.
2. It reconstructs the full `apostate_readback_noise.cc` and `.h` files from
   the actual upstream series. They originate as new files in patch 0120;
   patches 0168 and 0171 are applied with real `git apply --check`/`git apply`.
3. It runs real `git apply --check` and applies 0174 to those two complete
   reconstructed files. It records their before/after hashes and extracts the
   actual before/after `Exempt` function bodies.
4. It compiles those C++ function bodies with MSVC. Twelve tiny executable
   entry points return the before/after booleans through native process exit
   codes for 1, 8, 15, 16, 32, narrow, zero and negative dimensions. These are
   not JavaScript reimplementations of the predicate.

The CLI writes `verification.json`, including the exact commands and results.
Per-run replayed files, the generated C++, object file, native executables and
full report remain in ignored `.work/<run-id>/` directories for inspection.
The checker does not delete or move any user data.

## What Is Not Verified

- The original 0174 checker validates only its two reconstructed noise files.
  The separate `0176-check.ts` now fetches and hash-pins the complete relevant
  fixed-version sources, checks 0174's WebGL comment hunk and all of 0176 with
  real `git apply --check`. Neither checker compiles the Blink translation units.
- The C++ predicate regression does not compile Blink, the full readback
  algorithm or Chromium. It cannot establish that canvas cropping, encoding,
  ImageBitmap, WebGL packing/PBO readback, GPU execution, or workers agree.
- No WebGPU texture/buffer mapping or compute-isolation fix is implemented.
  Adapter labels and limits alone do not establish actual device behavior.
- No new browser binary was built or measured by this check. No detector
  acceptance, anonymity, or cross-profile unlinkability is claimed.

## Required Full-Build Gate

Before any runtime adoption, apply the full pinned series plus the ordered overlays in `series.overlay` to the
complete pinned Chromium checkout, check every hunk, compile the affected
translation units, then build and hash-pin a new versioned Windows runtime.
The original build, executable SHA-256, profiles and login sessions must remain
available unchanged until that candidate passes browser-level measurements.

Measure at least two fresh seeds and a host control. Each seed needs repeated
reads, refresh, process restart and all supported contexts. The browser suite
must include drawn and known/written pixels, 8/15/16/17/32 dimensions, whole vs
cropped reads, PNG/blob round-trips, canvas copies, OffscreenCanvas, WebGL
RGBA8/packing/FBO/PBO paths, actual WebGPU drawing and typed-buffer round-trips.
GPU identity, advertised capabilities and executable shader behavior must be
checked separately; different APIs are not expected to have identical hashes
for different rendering programs. A size-cutoff fix alone is not that gate.
