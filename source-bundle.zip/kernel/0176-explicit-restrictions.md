# Explicit Rendering Restrictions: Native Overlay, Not a Validated Runtime

Patch `0176-honor-explicit-rendering-restrictions-in-workers.patch` addresses
explicit operator restrictions only. It does not turn them on for normal
profiles and does not provide a different real GPU or normal-mode fingerprint
isolation. No JavaScript getter replacement, injected script or CDP override is
used.

## Scope of the Source Change

- Propagate the existing `disable-reading-from-canvas`, `disable-webgl`,
  `disable-webgl2` and `disable-3d-apis` switches to every renderer process,
  including renderers created for standalone workers.
- Make `OffscreenCanvas::OriginClean` honor the explicit process-wide canvas
  read restriction as well as its existing origin and inherited settings.
  Existing native tainted-canvas security errors then apply to the readback
  and export routes that check this boundary. Drawing is not disabled.
- At the common WebGL1/2 context-provider creation boundary, reject explicit
  process restrictions before creating either a hardware or software provider.
  Preserve frame/enterprise restrictions, and preserve WebGL1 when only WebGL2
  is disabled.

These restrictions are independent of the profile identity. Without the
switches, the new command-line predicates are false and the original native
behavior remains in place. This is a limited-capability policy, not hardware
simulation or proof of anonymity.

## Correct Parameter Names

The fixed Chromium 155 runtime-enabled feature registry does **not** contain a
feature named `WebGPU`. Consequently, `--disable-blink-features=WebGPU` is not a
valid WebGPU-disabling test for this version. The overlay deliberately does not
invent semantics for that unknown name.

The GPU service base feature exists as `WebGPUService`; its correct test
argument is `--disable-features=WebGPUService`. Do not combine that test with
`enable-unsafe-webgpu` or unrelated enabling overrides. A fresh-profile,
all-context runtime measurement is still required to establish the result.
This overlay does not change WebGPU service/adapter behavior.

`--disable-3d-apis` also exists in Chromium 155. Its original documented meaning
is to disable client-visible 3D APIs, particularly WebGL. Its frame preference
consumer disables WebGL1 and WebGL2. That is not by itself proof of a global
WebGPU-provider restriction. This overlay makes its existing WebGL meaning
explicit at the common native WebGL provider boundary, including workers.

## Reproduction and Evidence

```powershell
& '.\.tools\bun-windows-x64\bun.exe' local/kernel/0176-check.ts
& '.\.tools\bun-windows-x64\bun.exe' test ./local/kernel/0176-check.test.ts
```

The checker downloads only six fixed-tag source/evidence files, 966,356 bytes
in total. Each has an independent pinned SHA-256. It verifies the unchanged
upstream revision and complete ordered patch-series digest from `baseline.json`,
then replays every matching upstream patch against the complete files.

It additionally checks and applies the earlier 0174 WebGL comment hunk against
the now available **complete** original WebGL source. It then runs real
`git apply --check` and applies the entire 0176 overlay to all three complete
affected source files. This is not a context-only fixture check.

The actual new OffscreenCanvas guard body and WebGL command-line predicate are
extracted from that replay. MSVC compiles those snippets with small test doubles
for `CommandLine`, canvas fields and the context enum. Ten native unit cases
cover unrestricted behavior, each explicit switch, WebGL2-only restriction,
combined restrictions, uninitialized command-line state, unrelated flags,
existing taint and an existing inherited canvas restriction.

These snippet units test the actual C++ predicate bodies but **not** real base
command-line handling, renderer launch, Blink/GPU integration or a browser. The
renderer propagation binding is checked as source, not executed by those units.
The checker writes the exact commands, inputs, hashes, unit results and limits
to `0176-verification.json`; generated artifacts stay in ignored `.work/0176-*`.

## Still Required Before Adoption

No affected translation unit or full Chromium binary has been built by this
checker, and no candidate browser has been measured. Keep the current runtime,
existing profiles and login sessions unchanged until a separately versioned,
hash-pinned candidate is built and passes the unchanged headed matrix.

Use fresh profiles and verify Window, iframe, DedicatedWorker, SharedWorker
and ServiceWorker separately. Retain every readback/export assertion and
WebGL1/2 creation assertion. Test WebGPU with the valid service feature argument,
not the unknown Blink name. Assert that no forbidden adapter/context or pixel
read succeeds; do not count an exception from an unrelated setup failure as a
successful restriction. Repeat after refresh and a complete process restart.
The unrestricted host/control run must retain working APIs and ordinary pixel
semantics. Unsupported APIs, failed setup and unmeasured routes remain unverified.
