// local/audit/render-probe.ts
async function collectRenderSnapshot() {
  const digest = async (bytes) => {
    const value = await crypto.subtle.digest("SHA-256", new Uint8Array(bytes));
    return Array.from(new Uint8Array(value), (b) => b.toString(16).padStart(2, "0")).join("");
  };
  const equal = (a, b) => a.length === b.length && a.every((value, i) => value === b[i]);
  const crop = (pixels, stride, x, y, width, height) => {
    const out = new Uint8Array(width * height * 4);
    for (let row = 0;row < height; row++)
      out.set(pixels.subarray(((y + row) * stride + x) * 4, ((y + row) * stride + x + width) * 4), row * width * 4);
    return out;
  };
  const capture = async (fn) => {
    try {
      return await fn();
    } catch (error) {
      return { status: "error", reason: String(error) };
    }
  };
  const unsupported = (reason) => ({ status: "unsupported", reason });
  const nav = navigator;
  const identity = {
    ua: nav.userAgent,
    platform: nav.platform,
    cores: nav.hardwareConcurrency,
    memory: nav.deviceMemory,
    language: nav.language,
    languages: [...nav.languages],
    timezone: Intl.DateTimeFormat().resolvedOptions().timeZone
  };
  const width = 64, height = 64;
  const exposure = {};
  const observe = async (name, fn) => {
    try {
      const value = await fn();
      exposure[name] = value === null ? { status: "unsupported" } : { status: "readable", hash: await digest(typeof value === "string" ? new TextEncoder().encode(value) : value) };
    } catch (error) {
      const nameOfError = error instanceof Error ? error.name : "Error";
      exposure[name] = { status: nameOfError === "SecurityError" || nameOfError === "NotAllowedError" ? "blocked" : "error", reason: String(error) };
    }
  };
  const drawKnownScene = (ctx) => {
    ctx.fillStyle = "#f1b42c";
    ctx.fillRect(0, 0, width, height);
    ctx.fillStyle = "#243856";
    ctx.font = "17px Arial";
    ctx.fillText("Native readback 0123", 4, 24);
    ctx.beginPath();
    ctx.arc(32.15, 38.85, 13.7, 0, Math.PI * 2);
    ctx.fillStyle = "rgba(42,101,152,.63)";
    ctx.fill();
  };
  if (typeof document !== "undefined") {
    const dom = document.createElement("canvas");
    dom.width = width;
    dom.height = height;
    const ctx = dom.getContext("2d");
    if (ctx) {
      drawKnownScene(ctx);
      await observe("dom.getImageData", async () => new Uint8Array(ctx.getImageData(0, 0, width, height).data));
      await observe("dom.toDataURL", async () => dom.toDataURL());
      await observe("dom.toBlob", async () => {
        const blob = await new Promise((resolve) => dom.toBlob(resolve));
        if (!blob)
          throw new Error("Canvas export returned null");
        return new Uint8Array(await blob.arrayBuffer());
      });
      await observe("dom.copy", async () => {
        const copy = document.createElement("canvas");
        copy.width = width;
        copy.height = height;
        const copied = copy.getContext("2d");
        copied.drawImage(dom, 0, 0);
        return new Uint8Array(copied.getImageData(0, 0, width, height).data);
      });
      await observe("dom.offscreenCopy", async () => {
        if (typeof OffscreenCanvas === "undefined")
          return null;
        const copy = new OffscreenCanvas(width, height);
        const copied = copy.getContext("2d");
        copied.drawImage(dom, 0, 0);
        return new Uint8Array(copied.getImageData(0, 0, width, height).data);
      });
    }
  }
  if (typeof OffscreenCanvas !== "undefined") {
    const offscreen = new OffscreenCanvas(width, height);
    const ctx = offscreen.getContext("2d");
    if (ctx) {
      drawKnownScene(ctx);
      await observe("offscreen.getImageData", async () => new Uint8Array(ctx.getImageData(0, 0, width, height).data));
      await observe("offscreen.convertToBlob", async () => new Uint8Array(await (await offscreen.convertToBlob()).arrayBuffer()));
      await observe("offscreen.imageBitmapCopy", async () => {
        const bitmap = offscreen.transferToImageBitmap();
        try {
          const copy = new OffscreenCanvas(width, height);
          const copied = copy.getContext("2d");
          copied.drawImage(bitmap, 0, 0);
          return new Uint8Array(copied.getImageData(0, 0, width, height).data);
        } finally {
          bitmap.close();
        }
      });
    }
  }
  const palette = () => {
    const bytes = new Uint8Array(width * height * 4);
    for (let i = 0;i < width * height; i++) {
      bytes[i * 4] = (i * 13 + 21) % 256;
      bytes[i * 4 + 1] = (i * 7 + 81) % 256;
      bytes[i * 4 + 2] = (i * 3 + 45) % 256;
      bytes[i * 4 + 3] = 255;
    }
    return bytes;
  };
  const canvas = await capture(async () => {
    if (typeof OffscreenCanvas === "undefined")
      return unsupported("OffscreenCanvas unavailable");
    const surface = new OffscreenCanvas(width, height);
    const ctx = surface.getContext("2d", { willReadFrequently: true });
    if (!ctx)
      return unsupported("Canvas 2D unavailable");
    ctx.fillStyle = "#f1b42c";
    ctx.fillRect(0, 0, width, height);
    const gradient = ctx.createLinearGradient(0, 0, width, height);
    gradient.addColorStop(0, "#1864ab");
    gradient.addColorStop(1, "#c2255c");
    ctx.fillStyle = gradient;
    ctx.fillRect(6.25, 7.75, 45.5, 38.5);
    ctx.beginPath();
    ctx.arc(32.15, 30.85, 17.7, 0, Math.PI * 2);
    ctx.fillStyle = "rgba(42,101,152,.63)";
    ctx.fill();
    const first = new Uint8Array(ctx.getImageData(0, 0, width, height).data);
    const second = new Uint8Array(ctx.getImageData(0, 0, width, height).data);
    const part = ctx.getImageData(8, 8, 16, 16).data;
    const drawAtSize = (size) => {
      const c = new OffscreenCanvas(size, size);
      const g = c.getContext("2d", { willReadFrequently: true });
      g.fillStyle = "white";
      g.fillRect(0, 0, size, size);
      g.fillStyle = "rgb(42,101,152)";
      for (let y = 0;y < size; y += 8)
        for (let x = 0;x < size; x += 8) {
          g.beginPath();
          g.arc(x + 4.15, y + 3.85, 2.7, 0, Math.PI * 2);
          g.fill();
        }
      return g.getImageData(0, 0, size, size).data;
    };
    const small = drawAtSize(8), large = drawAtSize(32);
    const pixels = palette();
    ctx.putImageData(new ImageData(new Uint8ClampedArray(pixels), width, height), 0, 0);
    const roundTrip = ctx.getImageData(0, 0, width, height).data;
    ctx.fillStyle = "#2468ac";
    ctx.beginPath();
    ctx.arc(52.5, 52.5, 3, 0, Math.PI * 2);
    ctx.fill();
    const untouched = ctx.getImageData(0, 0, 16, 16).data;
    return {
      status: "ok",
      hash: await digest(first),
      repeat: await digest(second),
      checks: { repeat: equal(first, second), crop: equal(crop(first, width, 8, 8, 16, 16), part), sizeInvariant: equal(small, crop(large, 32, 0, 0, 8, 8)), exactPixels: equal(pixels, roundTrip), unchangedPixelsAfterDraw: equal(crop(pixels, width, 0, 0, 16, 16), untouched) },
      metadata: { width, height, textFree: true }
    };
  });
  const readGL = async (version) => {
    if (typeof OffscreenCanvas === "undefined")
      return unsupported("OffscreenCanvas unavailable");
    const surface = new OffscreenCanvas(width, height);
    const gl = surface.getContext(version, { antialias: false, preserveDrawingBuffer: true, premultipliedAlpha: false });
    if (!gl)
      return unsupported(`${version} unavailable`);
    try {
      const extension = gl.getExtension("WEBGL_debug_renderer_info");
      const metadata = {
        vendor: extension ? gl.getParameter(extension.UNMASKED_VENDOR_WEBGL) : gl.getParameter(gl.VENDOR),
        renderer: extension ? gl.getParameter(extension.UNMASKED_RENDERER_WEBGL) : gl.getParameter(gl.RENDERER),
        maxTextureSize: gl.getParameter(gl.MAX_TEXTURE_SIZE)
      };
      const shader = (type, source) => {
        const result = gl.createShader(type);
        if (!result)
          throw new Error("createShader failed");
        gl.shaderSource(result, source);
        gl.compileShader(result);
        if (!gl.getShaderParameter(result, gl.COMPILE_STATUS)) {
          const error = gl.getShaderInfoLog(result);
          gl.deleteShader(result);
          throw new Error(`Shader compilation failed: ${error}`);
        }
        return result;
      };
      const vertex = shader(gl.VERTEX_SHADER, version === "webgl2" ? `#version 300 es
in vec2 position; out vec2 p; void main(){p=position;gl_Position=vec4(position,0.,1.);}` : "attribute vec2 position; varying vec2 p; void main(){p=position;gl_Position=vec4(position,0.,1.);}");
      const fragment = shader(gl.FRAGMENT_SHADER, version === "webgl2" ? `#version 300 es
precision highp float; in vec2 p; out vec4 color; void main(){color=vec4(.5+.3*p.x,.5+.29*p.y,.35+.17*p.x*p.y,1.);}` : "precision highp float; varying vec2 p; void main(){gl_FragColor=vec4(.5+.3*p.x,.5+.29*p.y,.35+.17*p.x*p.y,1.);}");
      const program = gl.createProgram();
      if (!program)
        throw new Error("createProgram failed");
      gl.attachShader(program, vertex);
      gl.attachShader(program, fragment);
      gl.linkProgram(program);
      if (!gl.getProgramParameter(program, gl.LINK_STATUS))
        throw new Error("Program link failed");
      gl.useProgram(program);
      gl.bindBuffer(gl.ARRAY_BUFFER, gl.createBuffer());
      gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-0.8, -0.7, 0.85, -0.6, -0.15, 0.9]), gl.STATIC_DRAW);
      const location2 = gl.getAttribLocation(program, "position");
      gl.enableVertexAttribArray(location2);
      gl.vertexAttribPointer(location2, 2, gl.FLOAT, false, 0, 0);
      gl.viewport(0, 0, width, height);
      gl.clearColor(42 / 255, 101 / 255, 152 / 255, 1);
      gl.clear(gl.COLOR_BUFFER_BIT);
      gl.drawArrays(gl.TRIANGLES, 0, 3);
      gl.finish();
      const first = new Uint8Array(width * height * 4), second = new Uint8Array(first.length);
      gl.readPixels(0, 0, width, height, gl.RGBA, gl.UNSIGNED_BYTE, first);
      gl.readPixels(0, 0, width, height, gl.RGBA, gl.UNSIGNED_BYTE, second);
      const part = new Uint8Array(16 * 16 * 4);
      gl.readPixels(8, 8, 16, 16, gl.RGBA, gl.UNSIGNED_BYTE, part);
      const texture = gl.createTexture();
      gl.bindTexture(gl.TEXTURE_2D, texture);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
      const pixels = palette();
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, width, height, 0, gl.RGBA, gl.UNSIGNED_BYTE, pixels);
      gl.bindFramebuffer(gl.FRAMEBUFFER, gl.createFramebuffer());
      gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, texture, 0);
      if (gl.checkFramebufferStatus(gl.FRAMEBUFFER) !== gl.FRAMEBUFFER_COMPLETE)
        throw new Error("Texture framebuffer incomplete");
      const uploaded = new Uint8Array(pixels.length);
      gl.readPixels(0, 0, width, height, gl.RGBA, gl.UNSIGNED_BYTE, uploaded);
      const noError = gl.getError() === gl.NO_ERROR;
      return {
        status: "ok",
        hash: await digest(first),
        repeat: await digest(second),
        checks: { repeat: equal(first, second), crop: equal(crop(first, width, 8, 8, 16, 16), part), exactPixels: equal(pixels, uploaded), noError },
        metadata
      };
    } finally {
      gl.getExtension("WEBGL_lose_context")?.loseContext();
    }
  };
  const webgl = await capture(() => readGL("webgl"));
  const webgl2 = await capture(() => readGL("webgl2"));
  const webgpu = await capture(async () => {
    if (!nav.gpu)
      return unsupported("WebGPU unavailable");
    const adapter = await nav.gpu.requestAdapter();
    if (!adapter)
      return unsupported("WebGPU returned no adapter");
    const info = adapter.info ?? await adapter.requestAdapterInfo?.() ?? {};
    const subgroups = adapter.features.has("subgroups");
    const device = await adapter.requestDevice({ requiredFeatures: subgroups ? ["subgroups"] : [] });
    const validationErrors = [];
    device.addEventListener("uncapturederror", (event) => validationErrors.push(String(event.error)));
    const timeout = setTimeout(() => device.destroy(), 15000);
    try {
      const metadata = {
        vendor: info.vendor ?? "",
        architecture: info.architecture ?? "",
        device: info.device ?? "",
        description: info.description ?? "",
        features: [...adapter.features].sort(),
        maxTextureDimension2D: adapter.limits.maxTextureDimension2D,
        deviceMaxTextureDimension2D: device.limits.maxTextureDimension2D,
        subgroupMinSize: info.subgroupMinSize ?? null,
        subgroupMaxSize: info.subgroupMaxSize ?? null,
        subgroupSizes: []
      };
      const texture = device.createTexture({ size: [width, height], format: "rgba8unorm", usage: 1 | 2 | 16 });
      const module = device.createShaderModule({ code: `
        struct Vertex { @builtin(position) position: vec4f, @location(0) p: vec2f };
        @vertex fn vs(@builtin(vertex_index) i: u32) -> Vertex {
          let points = array(vec2f(-.8,-.7),vec2f(.85,-.6),vec2f(-.15,.9));
          var out: Vertex; out.position=vec4f(points[i],0.,1.); out.p=points[i]; return out;
        }
        @fragment fn fs(input: Vertex) -> @location(0) vec4f {
          let p=input.p; return vec4f(.5+.3*p.x,.5+.29*p.y,.35+.17*p.x*p.y,1.);
        }` });
      const pipeline = device.createRenderPipeline({ layout: "auto", vertex: { module, entryPoint: "vs" }, fragment: { module, entryPoint: "fs", targets: [{ format: "rgba8unorm" }] }, primitive: { topology: "triangle-list" } });
      const encoder = device.createCommandEncoder();
      const pass = encoder.beginRenderPass({ colorAttachments: [{ view: texture.createView(), clearValue: [42 / 255, 101 / 255, 152 / 255, 1], loadOp: "clear", storeOp: "store" }] });
      pass.setPipeline(pipeline);
      pass.draw(3);
      pass.end();
      device.queue.submit([encoder.finish()]);
      const readTexture = async () => {
        const buffer = device.createBuffer({ size: width * height * 4, usage: 1 | 8 });
        try {
          const copy = device.createCommandEncoder();
          copy.copyTextureToBuffer({ texture }, { buffer, bytesPerRow: width * 4 }, [width, height]);
          device.queue.submit([copy.finish()]);
          await buffer.mapAsync(1);
          const result = new Uint8Array(buffer.getMappedRange().slice(0));
          buffer.unmap();
          return result;
        } finally {
          buffer.destroy();
        }
      };
      const first = await readTexture(), second = await readTexture();
      const pixels = palette();
      device.queue.writeTexture({ texture }, pixels, { bytesPerRow: width * 4 }, [width, height]);
      const uploaded = await readTexture();
      const computeModule = device.createShaderModule({ code: "@group(0) @binding(0) var<storage,read_write> values: array<u32>; @compute @workgroup_size(1) fn main(@builtin(global_invocation_id) id: vec3u){values[id.x]=id.x*1664525u+1013904223u;}" });
      const computePipeline = device.createComputePipeline({ layout: "auto", compute: { module: computeModule, entryPoint: "main" } });
      const storage = device.createBuffer({ size: 256, usage: 128 | 4 });
      const output = device.createBuffer({ size: 256, usage: 1 | 8 });
      try {
        const commands = device.createCommandEncoder();
        const compute = commands.beginComputePass();
        compute.setPipeline(computePipeline);
        compute.setBindGroup(0, device.createBindGroup({ layout: computePipeline.getBindGroupLayout(0), entries: [{ binding: 0, resource: { buffer: storage } }] }));
        compute.dispatchWorkgroups(64);
        compute.end();
        commands.copyBufferToBuffer(storage, 0, output, 0, 256);
        device.queue.submit([commands.finish()]);
        await output.mapAsync(1);
        const actual = new Uint32Array(output.getMappedRange().slice(0));
        output.unmap();
        const exactCompute = actual.every((value, i) => value === Math.imul(i, 1664525) + 1013904223 >>> 0);
        const checks = { repeat: equal(first, second), exactPixels: equal(pixels, uploaded), exactCompute, noError: validationErrors.length === 0, limits: device.limits.maxTextureDimension2D <= adapter.limits.maxTextureDimension2D };
        if (subgroups) {
          const subgroupModule = device.createShaderModule({ code: "enable subgroups; @group(0) @binding(0) var<storage,read_write> values: array<u32>; @compute @workgroup_size(64) fn main(@builtin(global_invocation_id) id: vec3u,@builtin(subgroup_size) size: u32){values[id.x]=size;}" });
          const subgroupPipeline = device.createComputePipeline({ layout: "auto", compute: { module: subgroupModule, entryPoint: "main" } });
          const commands = device.createCommandEncoder();
          const compute = commands.beginComputePass();
          compute.setPipeline(subgroupPipeline);
          compute.setBindGroup(0, device.createBindGroup({ layout: subgroupPipeline.getBindGroupLayout(0), entries: [{ binding: 0, resource: { buffer: storage } }] }));
          compute.dispatchWorkgroups(1);
          compute.end();
          commands.copyBufferToBuffer(storage, 0, output, 0, 256);
          device.queue.submit([commands.finish()]);
          await output.mapAsync(1);
          const sizes = new Uint32Array(output.getMappedRange().slice(0));
          output.unmap();
          metadata.subgroupSizes = [...new Set(sizes)].sort((a, b) => a - b);
          checks.subgroupDeclaration = typeof info.subgroupMinSize === "number" && typeof info.subgroupMaxSize === "number" && sizes.every((size) => size >= info.subgroupMinSize && size <= info.subgroupMaxSize);
        }
        checks.noError = validationErrors.length === 0;
        return {
          status: "ok",
          hash: await digest(first),
          repeat: await digest(second),
          checks,
          metadata
        };
      } finally {
        storage.destroy();
        output.destroy();
        texture.destroy();
      }
    } finally {
      clearTimeout(timeout);
      device.destroy();
    }
  });
  return { version: 1, identity, canvas, webgl, webgl2, webgpu, exposure };
}
function renderWorkerSource() {
  return `const collect=${collectRenderSnapshot.toString()};
const reply=async(port)=>{try{port.postMessage(await collect())}catch(error){port.postMessage({error:String(error)})}};
if(typeof ServiceWorkerGlobalScope!=="undefined"&&self instanceof ServiceWorkerGlobalScope){
self.addEventListener("install",event=>event.waitUntil(self.skipWaiting()));
self.addEventListener("activate",event=>event.waitUntil(self.clients.claim()));
self.addEventListener("message",event=>{if(event.ports[0])event.waitUntil(reply(event.ports[0]))});
}else if(typeof SharedWorkerGlobalScope!=="undefined"&&self instanceof SharedWorkerGlobalScope){
self.onconnect=event=>{const port=event.ports[0];port.onmessage=()=>reply(port);port.start()};
}else{self.onmessage=()=>reply(self)}`;
}
// local/audit/render-contexts.ts
async function collectRenderContexts(key) {
  const endpoint = `/probe/render-worker.js?key=${encodeURIComponent(key)}`;
  const fromWorker = (kind) => new Promise((resolve) => {
    let worker;
    let port;
    const timer = setTimeout(() => done({ error: `${kind} render probe timed out` }), 30000);
    const done = (result) => {
      clearTimeout(timer);
      if (worker instanceof Worker)
        worker.terminate();
      else if (port instanceof MessagePort)
        port.close();
      resolve(result);
    };
    try {
      worker = kind === "dedicated" ? new Worker(endpoint) : new SharedWorker(endpoint, { name: `render-audit-${crypto.randomUUID()}` });
      port = worker instanceof Worker ? worker : worker.port;
      port.onmessage = (event) => done(event.data);
      worker.onerror = () => done({ error: `${kind} render probe failed` });
      if (port instanceof MessagePort)
        port.start();
      port.postMessage("collect");
    } catch (error) {
      done({ error: String(error) });
    }
  });
  const fromFrame = () => new Promise((resolve) => {
    const frame = document.createElement("iframe");
    const nonce = crypto.randomUUID();
    frame.hidden = true;
    const timer = setTimeout(() => done({ error: "iframe render probe timed out" }), 30000);
    const done = (result) => {
      clearTimeout(timer);
      removeEventListener("message", receive);
      frame.remove();
      resolve(result);
    };
    const receive = (event) => {
      if (event.origin === location.origin && event.source === frame.contentWindow && event.data?.renderNonce === nonce)
        done(event.data.snapshot);
    };
    addEventListener("message", receive);
    frame.src = `/probe/render-frame?key=${encodeURIComponent(key)}&nonce=${nonce}`;
    document.body.append(frame);
  });
  const fromService = async () => {
    if (!navigator.serviceWorker)
      return { error: "ServiceWorker unavailable" };
    const scope = new URL("/probe/render-scope/", location.origin).href;
    const existing = await navigator.serviceWorker.getRegistration(scope);
    if (existing && existing.scope === scope && !existing.active?.scriptURL.startsWith(new URL("/probe/render-worker.js", location.origin).href))
      return { error: "Diagnostic service worker scope is occupied" };
    const registration = await navigator.serviceWorker.register(endpoint, { scope });
    try {
      const worker = await new Promise((resolve, reject) => {
        const timer = setTimeout(() => reject(new Error("ServiceWorker activation timed out")), 15000);
        const find = () => {
          const candidate = registration.active;
          if (candidate?.state === "activated") {
            clearTimeout(timer);
            resolve(candidate);
            return;
          }
          const pending = registration.installing ?? registration.waiting ?? candidate;
          if (pending)
            pending.addEventListener("statechange", find, { once: true });
        };
        find();
      });
      return await new Promise((resolve) => {
        const channel = new MessageChannel;
        const timer = setTimeout(() => done({ error: "ServiceWorker render probe timed out" }), 30000);
        const done = (result) => {
          clearTimeout(timer);
          channel.port1.close();
          channel.port2.close();
          resolve(result);
        };
        channel.port1.onmessage = (event) => done(event.data);
        worker.postMessage("collect", [channel.port2]);
      });
    } finally {
      if (!existing || existing.scope !== scope)
        await registration.unregister();
    }
  };
  const safe = async (fn) => {
    try {
      return await fn();
    } catch (error) {
      return { error: String(error) };
    }
  };
  return {
    window: await safe(collectRenderSnapshot),
    iframe: await safe(fromFrame),
    dedicated: await safe(() => fromWorker("dedicated")),
    shared: await safe(() => fromWorker("shared")),
    service: await safe(fromService)
  };
}
// local/audit/render-contract.ts
var RENDER_SURFACES = ["canvas", "webgl", "webgl2", "webgpu"];
var CONTEXTS = ["window", "iframe", "dedicated", "shared", "service"];
var HASH = /^[a-f0-9]{64}$/;
var REQUIRED_PIXEL_CHECKS = {
  canvas: ["repeat", "crop", "sizeInvariant", "exactPixels", "unchangedPixelsAfterDraw"],
  webgl: ["repeat", "crop", "exactPixels", "noError"],
  webgl2: ["repeat", "crop", "exactPixels", "noError"],
  webgpu: ["repeat", "exactPixels", "exactCompute", "noError", "limits"]
};
var KNOWN_PIXEL_CASES = [
  "partial-put-with-no-later-draw",
  "partial-put-then-disjoint-antialiased-draw",
  "full-put-then-disjoint-antialiased-draw",
  "hollow-stroke-bounds-enclose-written-pixels",
  "transparent-source-over-is-a-no-op",
  "destination-over-preserves-opaque-written-pixels",
  "transform-disjoint-draw",
  "clip-excludes-written-pixels",
  "disjoint-filtered-draw",
  "disjoint-shadowed-draw",
  "copy-composite-clears-uncovered-written-pixels",
  "clear-rect-is-not-suppressed"
];
function knownPixelContractPassed(value) {
  if (!value || typeof value !== "object")
    return false;
  const report = value;
  if (report.version !== 2 || report.passed !== true || !Array.isArray(report.results) || report.results.length !== KNOWN_PIXEL_CASES.length * 8)
    return false;
  const remaining = new Set(["dom", "offscreen"].flatMap((kind) => ["region", "whole"].flatMap((read) => ["default", "willReadFrequently"].flatMap((backend) => KNOWN_PIXEL_CASES.map((name) => `${kind}:${read}:${backend}:${name}`)))));
  for (const row of report.results) {
    if (!row || typeof row !== "object" || row.status !== "pass" || row.beforeChangedBytes !== 0 || row.afterChangedBytes !== 0 || !remaining.delete(`${row.canvasKind}:${row.readMode}:${row.backend}:${row.name}`))
      return false;
  }
  return remaining.size === 0;
}
function snapshot(value) {
  return !!value && "version" in value && value.version === 1 && !!value.identity;
}
function usable(sample, surface) {
  return !!sample && sample.status === "ok" && HASH.test(sample.hash) && HASH.test(sample.repeat) && sample.hash === sample.repeat && REQUIRED_PIXEL_CHECKS[surface].every((name) => sample.checks[name] === true) && Object.values(sample.checks).every((pass) => pass === true) && (surface !== "webgpu" || !Array.isArray(sample.metadata.features) || !sample.metadata.features.includes("subgroups") || sample.checks.subgroupDeclaration === true);
}
function check(id, label, status, detail) {
  return { id, label, status, pass: status === "pass", detail };
}
function family(value) {
  if (typeof value !== "string")
    return null;
  for (const [name, expression] of [
    ["software", /swiftshader|llvmpipe|software|basic render/i],
    ["intel", /intel/i],
    ["nvidia", /nvidia/i],
    ["amd", /amd|radeon|\bati\b/i],
    ["apple", /apple/i],
    ["qualcomm", /qualcomm|adreno/i]
  ])
    if (expression.test(value))
      return name;
  return null;
}
function evaluateRenderContexts(contexts) {
  const results = [];
  const main = contexts.window;
  for (const name of CONTEXTS) {
    const value = contexts[name];
    results.push(check(`context.${name}`, `${name}: native rendering probe`, snapshot(value) ? "pass" : "unverified", snapshot(value) ? "Collected in this browsing context" : value && ("error" in value) ? value.error : "No observation"));
  }
  if (!snapshot(main))
    return results;
  const identityDifferences = CONTEXTS.filter((name) => {
    const value = contexts[name];
    return !snapshot(value) || JSON.stringify(value.identity) !== JSON.stringify(main.identity);
  });
  results.push(check("identity.contexts", "Identity: Window / iframe / Workers", identityDifferences.length ? "fail" : "pass", identityDifferences.length ? identityDifferences.join(", ") : "Seven identity fields match"));
  for (const surface of RENDER_SURFACES) {
    const required = surface === "webgpu" ? ["window", "iframe", "dedicated"] : CONTEXTS;
    const samples = required.map((name) => {
      const value = contexts[name];
      return { name, sample: snapshot(value) ? value[surface] : undefined };
    });
    const unavailable = samples.filter(({ sample }) => !sample || sample.status !== "ok");
    const invalid = samples.filter(({ sample }) => sample?.status === "ok" && !usable(sample, surface));
    const hashes = new Set(samples.filter(({ sample }) => usable(sample, surface)).map(({ sample }) => sample.status === "ok" ? sample.hash : ""));
    const status = invalid.length || hashes.size > 1 ? "fail" : unavailable.length ? "unverified" : "pass";
    const details = samples.map(({ name, sample }) => {
      if (!sample)
        return `${name}: missing`;
      if (sample.status !== "ok")
        return `${name}: ${sample.status} (${sample.reason})`;
      const failed = [...new Set([
        ...REQUIRED_PIXEL_CHECKS[surface].filter((key) => sample.checks[key] !== true),
        ...Object.entries(sample.checks).filter(([, pass]) => !pass).map(([key]) => key)
      ])];
      return `${name}: ${usable(sample, surface) ? sample.hash.slice(0, 12) : `invalid readback ${failed.join(",")}`}`;
    });
    results.push(check(`render.${surface}.contexts`, `${surface}: repeated reads / exact pixels / context agreement`, status, details.join("; ")));
    if (surface === "webgpu") {
      for (const name of ["shared", "service"]) {
        const value = contexts[name];
        const sample = snapshot(value) ? value.webgpu : undefined;
        const extraStatus = sample?.status === "ok" ? usable(sample, "webgpu") && sample.hash === (usable(main.webgpu, "webgpu") ? main.webgpu.hash : null) ? "pass" : "fail" : sample?.status === "error" ? "fail" : "unverified";
        results.push(check(`coverage.webgpu.${name}`, `WebGPU: ${name} coverage`, extraStatus, sample?.status === "unsupported" ? sample.reason : "Optional exposure; unavailable is not a verified result"));
      }
    }
  }
  const { webgl: gl, webgpu: gpu } = main;
  const glFamily = gl.status === "ok" ? family(gl.metadata.renderer) ?? family(gl.metadata.vendor) : null;
  const gpuFamily = gpu.status === "ok" ? family(gpu.metadata.description) ?? family(gpu.metadata.vendor) : null;
  results.push(check("graphics.family", "WebGL / WebGPU: declared GPU family", !glFamily || !gpuFamily ? "unverified" : glFamily === gpuFamily ? "pass" : "fail", `${glFamily ?? "unknown"} / ${gpuFamily ?? "unknown"}; this does not prove hardware identity`));
  return results;
}
function compareRenderSessions(first, next, relation) {
  const a = first.window, b = next.window;
  return RENDER_SURFACES.map((surface) => {
    const left = snapshot(a) ? a[surface] : undefined;
    const right = snapshot(b) ? b[surface] : undefined;
    if (!usable(left, surface) || !usable(right, surface))
      return check(`session.${surface}`, `${surface}: ${relation}`, "unverified", "Both sessions need valid native readbacks");
    const equal = left.hash === right.hash;
    const pass = relation === "same-profile" ? equal && JSON.stringify(left.metadata) === JSON.stringify(right.metadata) : !equal;
    return check(`session.${surface}`, `${surface}: ${relation}`, pass ? "pass" : "fail", `${left.hash.slice(0, 12)} / ${right.hash.slice(0, 12)}${equal ? " (identical)" : " (different)"}`);
  });
}
function evaluateHardwareRestriction(control, candidate) {
  const results = [];
  const offscreen = ["offscreen.getImageData", "offscreen.convertToBlob", "offscreen.imageBitmapCopy"];
  const dom = ["dom.getImageData", "dom.toDataURL", "dom.toBlob", "dom.copy", "dom.offscreenCopy"];
  for (const name of CONTEXTS) {
    const source = control[name], target = candidate[name];
    for (const route of [...name === "window" || name === "iframe" ? dom : [], ...offscreen]) {
      const baseline = snapshot(source) ? source.exposure?.[route] : undefined;
      const observed = snapshot(target) ? target.exposure?.[route] : undefined;
      const hasControl = baseline?.status === "readable" && HASH.test(baseline.hash ?? "");
      const status = !hasControl || !observed ? "unverified" : observed.status === "blocked" ? "pass" : "fail";
      results.push(check(`privacy.${name}.${route}`, `${name}: restrict ${route}`, status, !hasControl ? "No readable native control" : `Native control readable; candidate ${observed?.status ?? "missing"}. This tests explicit access restriction, not anonymity.`));
    }
    for (const surface of ["webgl", "webgl2", "webgpu"]) {
      const baseline = snapshot(source) ? source[surface] : undefined;
      const observed = snapshot(target) ? target[surface] : undefined;
      const denied = observed?.status === "unsupported" || observed?.status === "error" && /^(SecurityError|NotAllowedError):/.test(observed.reason);
      const status = !usable(baseline, surface) || !observed ? "unverified" : denied ? "pass" : "fail";
      results.push(check(`privacy.${name}.${surface}`, `${name}: restrict ${surface} access`, status, !usable(baseline, surface) ? "No working native control" : `Native control working; candidate ${observed?.status ?? "missing"}. API restriction is distinguishable and is not a hardware persona.`));
    }
  }
  return results;
}
// local/kernel/0175-known-pixels.ts
function runKnownPixelRegression() {
  const results = [];
  const side = 64;
  const knownX = 24;
  const knownY = 24;
  const knownSide = 8;
  const cases = [
    { name: "partial-put-with-no-later-draw", expected: "written", draw() {} },
    {
      name: "partial-put-then-disjoint-antialiased-draw",
      expected: "written",
      draw(context) {
        context.beginPath();
        context.arc(51.25, 51.75, 5.4, 0, Math.PI * 2);
        context.fill();
      }
    },
    {
      name: "full-put-then-disjoint-antialiased-draw",
      fullPut: true,
      expected: "written",
      draw(context) {
        context.beginPath();
        context.arc(51.25, 51.75, 5.4, 0, Math.PI * 2);
        context.fill();
      }
    },
    {
      name: "hollow-stroke-bounds-enclose-written-pixels",
      expected: "written",
      draw(context) {
        context.lineWidth = 1.5;
        context.strokeRect(2.25, 2.25, 59.5, 59.5);
      }
    },
    {
      name: "transparent-source-over-is-a-no-op",
      expected: "written",
      draw(context) {
        context.globalAlpha = 0;
        context.fillRect(0.25, 0.25, 63.5, 63.5);
      }
    },
    {
      name: "destination-over-preserves-opaque-written-pixels",
      expected: "written",
      draw(context) {
        context.globalCompositeOperation = "destination-over";
        context.beginPath();
        context.arc(28, 28, 24.5, 0, Math.PI * 2);
        context.fill();
      }
    },
    {
      name: "transform-disjoint-draw",
      expected: "written",
      draw(context) {
        context.translate(44, 44);
        context.rotate(0.2);
        context.fillRect(0.25, 0.25, 8.5, 8.5);
      }
    },
    {
      name: "clip-excludes-written-pixels",
      expected: "written",
      draw(context) {
        context.beginPath();
        context.rect(48, 48, 8, 8);
        context.clip();
        context.beginPath();
        context.arc(32, 32, 32.5, 0, Math.PI * 2);
        context.fill();
      }
    },
    {
      name: "disjoint-filtered-draw",
      expected: "written",
      draw(context) {
        context.filter = "blur(2px)";
        context.fillRect(50.25, 50.25, 5.5, 5.5);
      }
    },
    {
      name: "disjoint-shadowed-draw",
      expected: "written",
      draw(context) {
        context.shadowColor = "rgba(40,50,60,.8)";
        context.shadowBlur = 2;
        context.shadowOffsetX = 3;
        context.shadowOffsetY = 3;
        context.fillRect(50.25, 50.25, 5.5, 5.5);
      }
    },
    {
      name: "copy-composite-clears-uncovered-written-pixels",
      expected: "cleared",
      draw(context) {
        context.globalCompositeOperation = "copy";
        context.fillRect(48.25, 48.25, 8.5, 8.5);
      }
    },
    {
      name: "clear-rect-is-not-suppressed",
      expected: "cleared",
      draw(context) {
        context.clearRect(knownX, knownY, knownSide, knownSide);
      }
    }
  ];
  const canvasKinds = typeof document === "undefined" ? ["offscreen"] : ["dom", "offscreen"];
  for (const canvasKind of canvasKinds)
    for (const readMode of ["region", "whole"])
      for (const backend of ["default", "willReadFrequently"]) {
        for (const entry of cases) {
          try {
            const canvas = canvasKind === "offscreen" ? new OffscreenCanvas(side, side) : document.createElement("canvas");
            canvas.width = side;
            canvas.height = side;
            const context = canvas.getContext("2d", backend === "willReadFrequently" ? { willReadFrequently: true } : undefined);
            if (!context)
              throw new Error("Canvas 2D context is unavailable");
            context.fillStyle = "rgb(247,245,239)";
            context.fillRect(0, 0, side, side);
            context.fillStyle = "rgb(17,83,149)";
            context.beginPath();
            context.arc(8.3, 8.7, 4.2, 0, Math.PI * 2);
            context.fill();
            const imageSide = entry.fullPut ? side : knownSide;
            const image = context.createImageData(imageSide, imageSide);
            for (let y = 0;y < imageSide; y++)
              for (let x = 0;x < imageSide; x++) {
                const index = (y * imageSide + x) * 4;
                image.data[index] = 1 + (x * 13 + y * 7) % 253;
                image.data[index + 1] = 1 + (x * 19 + y * 17 + 81) % 253;
                image.data[index + 2] = 1 + (x * 23 + y * 29 + 45) % 253;
                image.data[index + 3] = 255;
              }
            context.putImageData(image, entry.fullPut ? 0 : knownX, entry.fullPut ? 0 : knownY);
            const expected = new Uint8ClampedArray(knownSide * knownSide * 4);
            for (let y = 0;y < knownSide; y++)
              for (let x = 0;x < knownSide; x++) {
                const sourceX = entry.fullPut ? knownX + x : x;
                const sourceY = entry.fullPut ? knownY + y : y;
                const sourceIndex = (sourceY * imageSide + sourceX) * 4;
                const destination = (y * knownSide + x) * 4;
                for (let channel = 0;channel < 4; channel++)
                  expected[destination + channel] = image.data[sourceIndex + channel];
              }
            const changed = (pixels, cleared) => {
              let count = 0;
              for (let i = 0;i < pixels.length; i++)
                if (pixels[i] !== (cleared ? 0 : expected[i]))
                  count++;
              return count;
            };
            const readKnownPixels = () => {
              if (readMode === "region")
                return context.getImageData(knownX, knownY, knownSide, knownSide).data;
              const whole = context.getImageData(0, 0, side, side).data;
              const selected = new Uint8ClampedArray(knownSide * knownSide * 4);
              for (let y = 0;y < knownSide; y++) {
                const start = ((knownY + y) * side + knownX) * 4;
                selected.set(whole.subarray(start, start + knownSide * 4), y * knownSide * 4);
              }
              return selected;
            };
            const beforeChangedBytes = changed(readKnownPixels(), false);
            context.save();
            entry.draw(context);
            context.restore();
            const afterChangedBytes = changed(readKnownPixels(), entry.expected === "cleared");
            results.push({
              name: entry.name,
              backend,
              canvasKind,
              readMode,
              beforeChangedBytes,
              afterChangedBytes,
              status: beforeChangedBytes === 0 && afterChangedBytes === 0 ? "pass" : "fail"
            });
          } catch (error) {
            results.push({ name: entry.name, backend, canvasKind, readMode, status: "error", error: String(error) });
          }
        }
      }
  return {
    version: 2,
    results,
    passed: results.length === cases.length * 2 * 2 * canvasKinds.length && results.every((row) => row.status === "pass"),
    scope: "Known opaque pixels, DOM/OffscreenCanvas and region/whole readback; needs a native control and does not establish full rendering isolation"
  };
}
export {
  collectRenderContexts,
  collectRenderSnapshot,
  compareRenderSessions,
  evaluateHardwareRestriction,
  evaluateRenderContexts,
  knownPixelContractPassed,
  renderWorkerSource,
  runKnownPixelRegression
};
